J&A Moving Service - Deploy Guide

FRONTEND (Vercel):
1. Upload /frontend folder to GitHub
2. Import into Vercel
3. Click Deploy

BACKEND (Render):
1. Upload /backend to GitHub
2. Create New Web Service on Render
3. Start command: node server.js

DONE.
